/*
 * 006filter.c
 * Versión optimizada con cambios mínimos
 */

#include "stm32f446.h"

TIM_Handle_t *pTIM ;
GPIO_Handle_t *pGPIO;
ADC_Handle_t *pADC;
uint16_t value;

int main(void)
{
	SystemCLK_Config_84MHz();

	GPIO_Handle_t GpioLed;
	pGPIO = &GpioLed;
	GPIO_PeriClockControl(GPIOA, ENABLE);

	GpioLed.pGPIOx = GPIOA;
	GpioLed.GPIO_PinConfig.GPIO_PinNumber = GPIO_PIN_NO_5;
	GpioLed.GPIO_PinConfig.GPIO_PinMode = GPIO_MODE_OUTPUT;
	GpioLed.GPIO_PinConfig.GPIO_PinSpeed = GPIO_SPEED_FAST;
	GpioLed.GPIO_PinConfig.GPIO_PinOPType = GPIO_OP_TYPE_PP;
	GpioLed.GPIO_PinConfig.GPIO_PinPuPdControl = GPIO_NO_PUPD;
	GPIO_Init(&GpioLed);

	GPIO_Handle_t GpioD;
	GpioD.pGPIOx = GPIOA;
	GpioD.GPIO_PinConfig.GPIO_PinNumber = GPIO_PIN_NO_8;
	GpioD.GPIO_PinConfig.GPIO_PinMode = GPIO_MODE_OUTPUT;
	GpioD.GPIO_PinConfig.GPIO_PinSpeed = GPIO_SPEED_FAST;
	GpioD.GPIO_PinConfig.GPIO_PinOPType = GPIO_OP_TYPE_PP;
	GpioD.GPIO_PinConfig.GPIO_PinPuPdControl = GPIO_NO_PUPD;
	GPIO_Init(&GpioD);

	GPIO_WriteToOutputPin(GPIOA, 5, 1);

    GPIO_Handle_t ADCIn_0;
    ADCIn_0.pGPIOx = GPIOA;
    ADCIn_0.GPIO_PinConfig.GPIO_PinMode = GPIO_MODE_ANALOG;
    ADCIn_0.GPIO_PinConfig.GPIO_PinNumber = GPIO_PIN_NO_4;
    ADCIn_0.GPIO_PinConfig.GPIO_PinPuPdControl = GPIO_NO_PUPD;
    GPIO_Init(&ADCIn_0);

    ADC_Handle_t ADC_channel_0;
    pADC = &ADC_channel_0;
    ADC_PeriClockControl(ADC1, ENABLE);

    ADC_channel_0.pADCx = ADC1;
    ADC_channel_0.ADC_Config.ADC_Resolution = ADC_RESOLUTION_12_B;
    ADC_channel_0.ADC_Config.ADC_DataAlignment = ADC_DATA_ALIGNMENT_RIGHT;
    ADC_channel_0.ADC_Config.ADC_ScanMode =  ADC_SCAN_MODE_DI;
    ADC_channel_0.ADC_Config.ADC_ConversionMode =  ADC_CONV_MODE_SINGLE;
    ADC_channel_0.ADC_Config.ADC_ExternalTriggerDetection =  ADC_EXT_TRIG_DECT_DI;
    ADC_channel_0.ADC_Config.ADC_ExternalTrigger =  0;
    ADC_channel_0.ADC_Config.ADC_DMAContinuousRequests =  ADC_DMA_MODE_DI;
    ADC_channel_0.ADC_Config.ADC_EOCSelection =  ADC_EOC_PER_CONVERSION;
    ADC_channel_0.ADC_Config.ADC_EOCInterrupt =  ADC_EOC_IT_DI;

    ADC_channel_0.ADC_NumChannels = 1;
    ADC_ChannelConfig(&ADC_channel_0, 4, 0, ADC_SMP_T_15);
    ADC_ConfigSequence(&ADC_channel_0);
    ADC_Init(&ADC_channel_0);

	TIM_Handle_t TIM_2;
	pTIM = &TIM_2;
	TIM_2.pTIMx = TIM2;
	TIM_2.TIM_Config.TIM_Frequency = 9600;        // Frecuencia más baja
	TIM_2.TIM_Config.TIM_CLKDivision = TIM_CKD_DIV1;
	TIM_2.TIM_Config.TIM_AutoReloadPreload = TIM_ARPE_ENABLE;
	TIM_2.TIM_Config.TIM_CNTMode = TIM_UPCOUNT_MODE;
	TIM_2.TIM_Config.TIM_IntEnable = TIM_IT_ENABLE;
	TIM_2.TIM_Config.TIM_MasterModeSel = TIM_MMS_RESET;  // Sin TRGO
	TIM_Init(&TIM_2);

	TIM_Start(&TIM_2);
	TIM_IRQInterruptConfig(IRQ_NO_TIM2, ENABLE);
	TIM_IRQPriorityConfig(IRQ_NO_TIM2, 0);

	while(1);
	return 0;
}

void TIM2_IRQHandler(void)
{
    TIM_IRQHandling(pTIM);
    ADC_StartConversion(pADC);
    while(!(ADC_GetConversionStatus(pADC)));
    value = ADC_ReadData(pADC) & 0x0FFF;

    if(value >= 2000)
    {
        GPIO_WriteToOutputPin(GPIOA, GPIO_PIN_NO_8, 1);
        GPIO_WriteToOutputPin(GPIOA, GPIO_PIN_NO_5, 1);
    }
    else
    {
        GPIO_WriteToOutputPin(GPIOA, GPIO_PIN_NO_8, 0);
        GPIO_WriteToOutputPin(GPIOA, GPIO_PIN_NO_5, 0);
    }
}
