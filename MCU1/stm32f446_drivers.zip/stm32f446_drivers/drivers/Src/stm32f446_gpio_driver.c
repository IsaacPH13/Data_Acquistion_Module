/*
 * stm32f446_gpio_driver.c
 *
 *  Created on: Oct 7, 2025
 *      Author: Isaac Pérez (ShiLiba)
 */

#include "stm32f446_gpio_driver.h"

/************************************************************************************
 * @fn				- GPIO_PeriClockControl
 *
 * @brief			- This function enables or disables peripheral clock for the given GPIO port
 *
 * @param[in]		- base address of the gpio peripheral
 * @param[in]		- ENABLE or DISABLE macros
 * @param[in]		-
 *
 * @return			- none
 *
 * @Note			- none
 *
 * */
void GPIO_PeriClockControl(GPIO_RegDef_t *pGPIOx, uint8_t EnorDi)
{
	if(EnorDi == ENABLE)
	{
		if (pGPIOx == GPIOA) GPIOA_CLK_EN();
		else if (pGPIOx == GPIOB) GPIOB_CLK_EN();
		else if (pGPIOx == GPIOC) GPIOC_CLK_EN();
		else if (pGPIOx == GPIOD) GPIOD_CLK_EN();
		else if (pGPIOx == GPIOE) GPIOE_CLK_EN();
		else if (pGPIOx == GPIOF) GPIOF_CLK_EN();
		else if (pGPIOx == GPIOG) GPIOG_CLK_EN();
		else if (pGPIOx == GPIOH) GPIOH_CLK_EN();
	}
	else
	{
		if (pGPIOx == GPIOA) GPIOA_CLK_DI();
		else if (pGPIOx == GPIOB) GPIOB_CLK_DI();
		else if (pGPIOx == GPIOC) GPIOC_CLK_DI();
		else if (pGPIOx == GPIOD) GPIOD_CLK_DI();
		else if (pGPIOx == GPIOE) GPIOE_CLK_DI();
		else if (pGPIOx == GPIOF) GPIOF_CLK_DI();
		else if (pGPIOx == GPIOG) GPIOG_CLK_DI();
		else if (pGPIOx == GPIOH) GPIOH_CLK_DI();
	}
}

/************************************************************************************
 * @fn				- GPIO_Init
 *
 * @brief			- This function initializes a given gpio
 *
 * @param[in]		- base address of the gpio peripheral
 *
 * @return			- none
 *
 * @Note			- none
 *
 * */
void GPIO_Init(GPIO_Handle_t *pGPIOHandle)
{
	uint32_t temp = 0;
	//1 . configure the mode of gpio pin
	if(pGPIOHandle->GPIO_PinConfig.GPIO_PinMode <= GPIO_MODE_ANALOG)
	{
		//the non interrupt mode
		temp = ( pGPIOHandle->GPIO_PinConfig.GPIO_PinMode << (2 * pGPIOHandle->GPIO_PinConfig.GPIO_PinNumber) );
		pGPIOHandle->pGPIOx->MODER = temp;
	} else
	{
		//this part will code later
	}
	temp = 0;
	//2. configure the speed
	temp = ( pGPIOHandle->GPIO_PinConfig.GPIO_PinSpeed << (2 * pGPIOHandle->GPIO_PinConfig.GPIO_PinNumber) );
	pGPIOHandle->pGPIOx->OSPEEDR = temp;
	temp = 0;
	//3. configure the pupd settings
	temp = ( pGPIOHandle->GPIO_PinConfig.GPIO_PinPudControl << (2 * pGPIOHandle->GPIO_PinConfig.GPIO_PinNumber) );
	pGPIOHandle->pGPIOx->PUPDR = temp;
	temp = 0;
	//4. configures the optype
	temp = ( pGPIOHandle->GPIO_PinConfig.GPIO_PinPuPdControl << (2 * pGPIOHandle->GPIO_PinConfig.GPIO_PinNumber) );
	pGPIOHandle->pGPIOx->PUPDR = temp;
	temp = 0;
	//5. configure the alt functionality
	temp = ( pGPIOHandle->GPIO_PinConfig.GPIO_PinAltFunMode << (2 * pGPIOHandle->GPIO_PinConfig.GPIO_PinNumber) );
	pGPIOHandle->pGPIOx->AFR= temp;
	temp = 0;
}
